const mysql = require('mysql2');
const config = require('./files/config.json')
const kafka = require("./kafka/kafka")
const kafkaConfig = require('./files/kafka.json')
const yargs = require('yargs');
const fs = require('fs');
const TemplateInfoId = require('./files/exportTemplateInfo.json')

var options = {
    host: config.host,
    user: config.user,
    database: config.database,
    password: config.password,
    waitForConnections: config.waitForConnections,
    connectionLimit: config.connectionLimit,
    queueLimit: config.queueLimit,
    //queryTimeout: 6000000,
    //connectTimeout: 6000000,
}
async function getNameById(id) {
  let response = []
  response = TemplateInfoId.filter(function (tes) { return tes.id == id; })[0];

  if(undefined == undefined){
    var query = `SELECT * FROM vminew2.TemplateInfo where id= ${id};`
    resBd = false
    while(!resBd){
      resBd = await sql(options, query)
    }
    return resBd[0]
  }else{
    return response
  }

}

setTimeout(async ()=>{
  console.log((await getNameById(3)).id)
}, 10)

async function sql(options, query) {
  return new Promise((resolve, reject) => {
      const connection = mysql.createConnection(options);
      connection.on("error", (err, msg) => { reject(err) })

      connection.connect();

      connection.query(query, function (error, results, fields) {
          if (error) {
              reject(false)
          };
          //console.log(`Retornou ${results.length} linhas.`);
          connection.end();
          resolve(results)
      });

  })
}