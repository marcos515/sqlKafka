const yargs = require('yargs');
const fs = require("fs");
const exec = require('exec');
const restify = require('restify')

var args = yargs.argv

var globalLog = ""

const server = restify.createServer({
  name: 'SqlKafka',
  version: '1.0.0',
  formatters: {
    'text/html': function (req, res, body) {
      return body;
    }
  }
});

server.listen(args.port | 3000, function () {
  wLog(`Servidor online em: "http://${getIPAddress()}:${args.port | 3000}"`);
});

server.on('NotFound', function (req, res, err, cb) {
  res.send(404, fs.readFileSync('./sites/error.html', 'utf8'))
});

server.use(restify.plugins.bodyParser({ mapParams: true }));


server.get('/', (req, res) => {
  res.header("Content-Type", "text/html")
  res.header("Access-Control-Allow-Origin", "*")
  res.send(200, fs.readFileSync('./sites/index.html', 'utf8'))
});

server.post('/log', (req, res) => {
  res.header("Access-Control-Allow-Origin", "*")
  res.send(globalLog)
})

server.post('/command', (req, res) => {
  res.header("Access-Control-Allow-Origin", "*")
  wLog(jsonString(req.body))
  ValidCommand(jsonJson(req.body))
  res.send("Received command, processing...")
})

server.post('/clearLog', (req, res) => {
  res.header("Access-Control-Allow-Origin", "*")
  globalLog = ""
  res.send("Received command, processing...")
})

server.get('*/file/*',
  restify.plugins.serveStaticFiles('./')
);

function ValidCommand(json) {
  if (validValue(json.start) && validValue(json.end) && validValue(json.threads) && validValue(json.kafkaHost) && validValue(json.kafkaTopic)) {
    if (json.dispositivoId !== undefined) {
      if (validValue(json.dispositivoId)) {
        wLog("valido")
        main(json.start, json.end, json.threads, json.kafkaHost, json.kafkaTopic, json.dispositivoId)
      } else {
        wLog("Dispositivo id invalido")
      }
    } else {
      wLog("valido")
      main(json.start, json.end, json.threads, json.kafkaHost, json.kafkaTopic)
    }

  } else {
    wLog("Comando invalido")
  }
}
function validValue(value) {
  if (value == "" || value == null || value == 'null' || value == undefined || value == "undefined") {
    return false
  } else {
    return true
  }
}

function main(startp, endp, robotsp, kafkaHost, kafkaTopic, targetId) {
  let start = (startp * 1000)
  let end = (endp * 1000)
  let numRobots = robotsp
  let tempoPs = parseInt(end - start)
  let tempoR = (tempoPs / numRobots)
  let robotsJob = []

  wLog(`Tempo a ser processado: ${tempoPs / 60000} minutos`)
  wLog(`Tempo para cada robo: ${tempoR / 60000} minutos`)

  for (let index = 0; index < numRobots; index++) {
    robotsJob[index] = {
      start: (start + (tempoR * index)) / 1000,
      end: (start + (tempoR * (index + 1))) / 1000
    }

  }

  wLog(JSON.stringify(robotsJob))
  wLog("Iniciando execução... Aguarde.")
  if (targetId) {
    for (let index = 0; index < robotsJob.length; index++) {
      exec(["node", "robot", `--host=${kafkaHost}`, `--topic=${kafkaTopic}`, `--start=${robotsJob[index].start}`, `--end=${robotsJob[index].end}`, `--dispositivoId=${targetId}`], log.bind({ index: index + 1 }));

    }
  } else {
    for (let index = 0; index < robotsJob.length; index++) {
      exec(["node", "robot", `--host=${kafkaHost}`, `--topic=${kafkaTopic}`, `--start=${robotsJob[index].start}`, `--end=${robotsJob[index].end}`], log.bind({ index: index + 1 }));

    }
  }

//node robot --host=192.168.18.48:9092 --topic=data --start=1617706260 --end=1617709860
}

function log(err, out, code) {
  fs.writeFileSync("./files/errorLog.txt", fs.readFileSync("./files/errorLog.txt", 'utf-8') + "\n" + err)
  wLog(`Robot ${this.index} error: [ O Log de erro foi escrito no arquivo]`)
  wLog(`Robot ${this.index} out: [${out}]`)
  wLog(`Robot ${this.index} exit code: [${code}]`)
}

function getIPAddress() {
  var interfaces = require('os').networkInterfaces();
  for (var devName in interfaces) {
    var iface = interfaces[devName];

    for (var i = 0; i < iface.length; i++) {
      var alias = iface[i];
      if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal)
        return alias.address;
    }
  }
  return '0.0.0.0';
}

function wLog(msg) {
  console.log(msg)
  globalLog += msg + "\n";
}

function jsonString(json) {
  try {
    return JSON.stringify(json)
  } catch (err) {
    return json
  }
}

function jsonJson(json) {
  try {
    return JSON.parse(json)
  } catch (err) {
    return json
  }
}