const consumer = require('./consumer').consumer
const producer = require("./producer").producer

module.exports={
    consumer,
    producer
}